package com.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner;

import com.db.JdbcDatabase;
import com.service.Books;

public class JdbcBooksDao {
	
	JdbcDatabase obj;
	Connection con;
	PreparedStatement sat;
	Scanner sc;
	Books book;
	int ch;
	
	public JdbcBooksDao(){
		obj = new JdbcDatabase();
		sc = new Scanner(System.in);
	}
	
	public void showMenu() {
		System.out.println("Enter your choice : ");
		System.out.println("1. Display all the books ");
		System.out.println("2. Add a book ");
		System.out.println("3. Delete a book ");
		System.out.println("4. Update a book price");
		System.out.println("5. Find book by id ");
		System.out.println("6. Exit ");
	    ch = sc.nextInt();
	}
	
	public void displayAll() throws SQLException {
		
		Statement st = obj.dbConnection().createStatement();
		ResultSet records = st.executeQuery("select * from books");
		while(records.next()) {
			System.out.println(records.getInt(1)+" "+ records.getString(2)+" "+records.getInt(3)+" "+records.getString(4));
		}
		
		System.out.println("Press 0 for main menu :");
	    int c = sc.nextInt();
	    if(c == 0)
	    	this.showMenu();
	    else
	    	ch = 6;
	}
	
       public int getCh() {
		return ch;
	}

	public void setCh(int ch) {
		this.ch = ch;
	}

	public void add(Books b1) throws SQLException {
		
		con = obj.dbConnection();
	    sat = con.prepareStatement("insert into books values (?,?,?,?)");
	    sat.setInt(1, b1.getBookId());
	    sat.setString(2, b1.getTitle());
	    sat.setInt(3, b1.getPrice());
	    sat.setString(4, b1.getAuthor());
	    int status = sat.executeUpdate();
	    if(status == 1)
	    	System.out.println("Record added.");
	    else
	    	System.out.println("Record not added.");
		System.out.println("Press 0 for main menu :");
	    int c = sc.nextInt();
	    if(c == 0)
	    	this.showMenu();
	    else 
            ch = 6;
	    
	}
       
    public void findById(int id) throws SQLException {
   		
    	con = obj.dbConnection();
	    sat = con.prepareStatement("select * from books where id = ?");
	    sat.setInt(1, id);
	    ResultSet records = sat.executeQuery();
	    book = new Books(records.getInt(1),records.getString(2),records.getInt(3),records.getString(4));
		while(records.next()) {
			System.out.println(records.getInt(1)+" "+ records.getString(2)+" "+records.getInt(3)+" "+records.getString(4));
		}
   		System.out.println("Press 0 for main menu :");
   	    int c = sc.nextInt();
   	    if(c == 0)
   	    	this.showMenu();
   	    else
   	    	ch = 6;	
   	} 
    
      public void remove(int id) throws SQLException {
		
    	con = obj.dbConnection();
  	    sat = con.prepareStatement("delete from books where id = ?");
  	    
  	    int status = sat.executeUpdate();
	    if(status == 1)
	    	System.out.println("Record deleted.");
	    else
	    	System.out.println("Record not deleted.");
		
		System.out.println("Press 0 for main menu :");
	    int c = sc.nextInt();
	    if(c == 0)
	    	this.showMenu();
	    else
	    	ch = 6;
		
	}
      
      public void update(int id) throws SQLException {
  		
  		System.out.println("Enter the updated price : ");
  		Scanner sc = new Scanner(System.in);
  		int pr = sc.nextInt();
  		
  		con = obj.dbConnection();
  	    sat = con.prepareStatement("update books set Price = ? where id = ?");
  	    sat.setInt(1, pr);
  	    sat.setInt(2, id);
  	    int status = sat.executeUpdate();
	    if(status == 1)
	    	System.out.println("Record updated");
	    else
	    	System.out.println("Record not updated.");
  		
  		
  		System.out.println("Press 0 for main menu :");
  	    int c = sc.nextInt();
  	    if(c == 0)
  	    	this.showMenu();
  	    else
  	    	ch = 6;
  		
  	}


}
